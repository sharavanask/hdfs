from flask import Flask, render_template, request, jsonify
import stripe
import smtplib
import random
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import re

app = Flask(__name__)
EMAIL_REGEX = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
# Stripe Configuration
STRIPE_SECRET_KEY = 'sk_test_51R4lYnCkWmpI69NaAgVeNY19mCMN5QrYqpo46TOzgJgZcJjEdW3nL0oGiI80aWZ53vciuu0DfEwyIkxPdpkSLBxW00RUc3XUjB'
STRIPE_PUBLIC_KEY = 'pk_test_51R4lYnCkWmpI69Na83tFbMQ5JU3WPvLqSl1LsVq2TuqS7MWDRskgQelWFAlu3y4TmZ1FgANWpM9WDKDNk0PQfyL800PSGDWaev'
stripe.api_key = STRIPE_SECRET_KEY

MUSEUMS = [
    "National Museum, New Delhi",
    "Indian Museum, Kolkata",
    "Chhatrapati Shivaji Maharaj Vastu Sangrahalaya, Mumbai",
    "Salar Jung Museum, Hyderabad",
    "Government Museum, Chennai",
    "Dr. Bhau Daji Lad Museum, Mumbai",
    "Victoria Memorial Hall, Kolkata",
    "Albert Hall Museum, Jaipur",
    "Napier Museum, Thiruvananthapuram",
    "HAL Heritage Centre and Aerospace Museum, Bengaluru"
]

# Ticket cost
TICKET_COST = 50

# Dictionary to track user progress
user_sessions = {}

@app.route('/')
def index():
    return render_template('index.html', museums=MUSEUMS)

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message')
    session_id = request.json.get('session_id')
    
    if session_id not in user_sessions:
        user_sessions[session_id] = {}
    
    response = chatbot_response(user_input, session_id)
    return jsonify({'response': response})

def chatbot_response(message, session_id):
    user_data = user_sessions[session_id]
    
    if 'book' in message.lower():
        user_sessions[session_id] = {}  # Reset session to start fresh
        museum_list = "<br>".join([f"{i+1}. {museum}" for i, museum in enumerate(MUSEUMS)])
        return f"Please select a museum by entering its number:<br><br>{museum_list}"

    elif message.isdigit():
        if 'museum' not in user_data:
            museum_index = int(message) - 1
            if 0 <= museum_index < len(MUSEUMS):
                user_data['museum'] = MUSEUMS[museum_index]
                return f"You selected: {MUSEUMS[museum_index]}. Now, enter the number of tickets:"
            else:
                return "❌ Invalid choice. Please enter a valid museum number from the list above."
        
        else:
            if int(message) <= 0:
                return "❌ Invalid number of tickets. Please enter a valid number greater than 0."
            
            user_data['num_tickets'] = int(message)
            total_amount = int(message) * TICKET_COST
            payment_link = create_payment_link(total_amount)
            user_data['payment_link'] = payment_link
            return f'<a href="{payment_link}" target="_blank" style="color:blue; text-decoration:underline;">Click here to pay</a><br><br>If paid, send "I have paid".'

    elif 'i have paid' in message.lower():
        if 'num_tickets' in user_data:
            return "Please provide your email for the ticket confirmation."
        else:
            return "❌ Please book tickets first before confirming payment."

    elif re.match(EMAIL_REGEX, message): 
        user_data['email'] = message
        ticket_numbers = generate_tickets(user_data['num_tickets'])
        user_data['ticket_numbers'] = ticket_numbers
        email_body = f"""
Dear Valued Customer,

Thank you for booking your museum tickets with us! 🎟️ 

Here are your booking details:

🔹 Museum Name: {user_data['museum']}  
🔹 Number of Tickets: {user_data['num_tickets']}  

Your ticket numbers:  
{chr(10).join([f"🎫 Ticket {i+1}: {ticket}" for i, ticket in enumerate(ticket_numbers)])}

You can present these ticket numbers at the entrance for hassle-free entry.  
If you have any questions or need assistance, feel free to contact our support team.  

Best Regards,  
Museum Ticket Booking Agency  
📧 museum.bot31@gmail.com 
📞 +91 9444086004
"""
 
        send_email(message, "Your Museum Tickets", email_body)
        return f"{user_data['num_tickets']} tickets booked for {user_data['museum']} successfully! 🎟<br>" \
                f"Your Ticket Numbers: {', '.join(ticket_numbers)}<br><br>" \
                f"Tickets have been sent to {message}.<br><br>" \
                "Would you like to book another ticket?<br>" \
                "👉 Type 'book' to start a new booking.<br>" \
                "👉 Type 'end' to finish the chat."
    
    
    elif 'end' in message.lower():
        if 'museum' in user_data and 'num_tickets' in user_data and 'ticket_numbers' in user_data:
            user_sessions.pop(session_id, None)  # Clear session properly
            return "Thank you for using the Museum Ticket Chatbot! 🎟 Have a great time at the museum! 😊"
        else:
            return "❌ You haven't completed your booking yet. Please complete the process first."


    else:
        return "❌ Invalid response. Please enter the required detail correctly."



def create_payment_link(amount):
    session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
            'price_data': {
                'currency': 'inr',
                'product_data': {'name': 'Museum Ticket'},
                'unit_amount': amount * 100,
            },
            'quantity': 1,
        }],
        mode='payment',
        success_url='http://localhost:5000/success',
        cancel_url='http://localhost:5000/cancel',
    )
    return session.url

def generate_tickets(num_tickets):
    return [str(random.randint(100000, 999999)) for _ in range(num_tickets)]

def send_email(to_email, subject, body):
    sender_email = "museum.bot31@gmail.com"
    sender_password = "indlokjpdknpojbx"
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))
    
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, to_email, msg.as_string())
        server.quit()
        return "Email sent successfully!"
    except Exception as e:
        return f"Email failed: {str(e)}"

if __name__ == '__main__':
    app.run(debug=True)
